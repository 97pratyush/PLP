package com.cg.service;



import com.cg.bean.Transaction;
import com.cg.bean.User1;
import com.cg.model.InvoiceProductModel;

public interface InvoiceService {

	public InvoiceProductModel showInvoice(int orderid);

	public User1 getUser(int userid);

	public void saveTransaction(Transaction transactionObject);

	public Transaction showTransaction(int orderid);
}
