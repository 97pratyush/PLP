package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.SecurityAns;

public interface SecurityDAO extends JpaRepository<SecurityAns, String>{
	@Query("select p from SecurityAns p where p.emailId=?1")
	public List<String> getanswer(String email);
}
