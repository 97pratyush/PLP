import { Component } from "@angular/core";
import { AuthenticationService } from "../Services/authentication.service";
import { Router } from "@angular/router";

@Component({
    selector:'logout',
    template:''
})
export class LogoutComponent{
    constructor(private service:AuthenticationService, private router: Router){
        this.service.logout()
        this.router.navigate(['home'])
        
    }
}