import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Address } from '../models/app.address';
import { Observable } from 'rxjs';
import{Response} from "../models/response"



const httpOptions={
    headers: new HttpHeaders({ 'Content-Type' : 'application/json'})
};

@Injectable({
    providedIn:'root'
})

export class AddressService {
    constructor(private http:HttpClient){}

    private userUrl="http://localhost:5000/Address";

    public addData(address:Address): Observable<Response>{
        console.log(address);
        let object={
    "name":address.name,
    "emailId":address.emailId,
    "MobileNo":address.MobileNo,
    "MobileNo2":address.MobileNo2,
    "address":address.address,
    "address2":address.address2,
    "city":address.city,
    "state":address.state,
    "PinCode":address.PinCode
        }
        return this.http.post<Response>(this.userUrl + "/addAddress",object);
    }

}