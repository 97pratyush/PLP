import { Component } from '@angular/core';

import {Router} from '@angular/router';
import { PaymentService } from '../../Services/paymentservice';
import { ProductSingleService } from 'src/app/Services/showSingleProductService';

@Component({
    selector: 'payment',
    templateUrl: 'payment.html'
})

export class PaymentComponent {
    PaymentService: any;
    constructor(private router: Router, private paymentService: PaymentService, private singleproductservice: ProductSingleService){}

    payStore:any;
  
    addData(){
        this.paymentService.sendData(this.payStore).subscribe(
            res=>{
                if(res.status === 200){
                    alert("Order Placed")
                    // Flusing cart
                    this.singleproductservice.deleteCart().subscribe(
                        res=>{
                            if(res===true){
                                
                            }else{
                                alert("Transaction Fail")
                                this.router.navigate(['home'])
                            }
                        }
                    )
                    sessionStorage.setItem("tid", res.message);
                    this.router.navigate(['invoice'])                    
                }else{
                    alert(res.message)
                    this.router.navigate(['home']);
                }
            }
        );
    }
 }