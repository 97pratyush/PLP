import { Component } from '@angular/core';
import { dataService } from '../../Services/dataServiceMerchant';
import { Merchant } from '../../models/merchant';

@Component({
    selector: 'merchant',
    templateUrl: 'merchant.html'
})

export class MerchantComponent {

    merchant:Merchant = new Merchant()
    mid:string

    constructor( private service:dataService){
        this.mid = sessionStorage.getItem("merchant")
       this.refreshData(this.mid)
    }

    

    
    refreshData(mid){
    this.service.fetchMerchantDetails(this.mid).subscribe(
        data=>{
            console.log(data)
            this.merchant = data
            
        }
    )
    }
}