import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'admin',
  templateUrl: 'admin.component.html'
})
// tslint:disable-next-line: component-class-suffix
export class Admin implements OnInit{
  str:string;
  ngOnInit(): void {
    this.str = sessionStorage.getItem('admin')
    //alert(this.str2)
    if(this.str == null){
      this.router.navigate(['login'])
    }
  }

  
  constructor(private router:Router) {}
}

