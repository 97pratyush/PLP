import { Component, OnInit } from "@angular/core";
import { Product } from "../../models/product";
import { ProductService } from "../../Services/ProductServiceMerchant";
import { Merchant } from "../../models/merchant";
import { Router } from "@angular/router";
import{FileUploader} from 'ng2-file-upload'



@Component({
    selector: 'add-comp',
    templateUrl: 'addProduct.html',
    styleUrls:["addProduct.css"]
})

export class AddProductClass implements OnInit{
  ob: Product = new Product();
  submitted = false;
constructor(private  service: ProductService, private route:Router){}

productID: number;
productName: string;
merchantId: number;
company: string;
photo: string;
description: string;
quantity: number;
category: string;
subcategory: string;
soldQuantities: number;
price: number;
releaseDate: Date;
tags: string[]=[]
product: Product = new Product();
uploader: FileUploader;
isDropOver: boolean;
filler:number
ngOnInit() {
  this.filler=Math.random()
  const headers = [{name: 'Accept', value: 'application/json'},{name:'Number',value:this.filler.toString()}];

  this.uploader = new FileUploader({url: 'http://localhost:4000/api/files', autoUpload: false, headers: headers});

  this.uploader.onCompleteAll = () => alert('File uploaded');
}
onFileChanged(event){

  this.product.photo="D:\\Users\\habauska\\Desktop\\"+this.filler+event.target.files[0].name

}
AddData(){
  console.log("getmerchant")
  this.uploader.uploadAll()
  this.service.getMerchant(this.merchantId).subscribe(
    res=>{
      this.merchant = res;
      if(res == null){
        alert("Merchant not present")
      }else{
        this.product.productName = this.productName;
        this.product.merchant = this.merchant;
        this.product.company = this.company;
        this.tags.push(this.company);
        this.product.tag = this.tags;
        // this.product.photo = this.photo;
        this.product.description = this.description;
        this.product.quantity = this.quantity;
        this.product.category = this.category;
        this.product.subcategory = this.subcategory;
        this.product.soldQuantities = this.soldQuantities;
        this.product.price = this.price;
        this.product.releaseDate = this.releaseDate;

        console.log(this.tags)

        this.service.createProduct(this.product).subscribe(
          res=>console.log(res),
          err=>console.log(err)
        )
      }
    }, err=>alert(err)
  )
}

merchant: Merchant;

newProduct(): void {
  window.location.reload()
}

onSubmit() {
  this.submitted = true;
  this.AddData();
}
gotoshowproduct(){
  this.route.navigate(['showProduct'])
}
}
  