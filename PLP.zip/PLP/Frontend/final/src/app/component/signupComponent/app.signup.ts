import { Component } from '@angular/core'
import { RegistrationServiceComponent } from '../../Services/com.registrationservice';
import { UserWithSec } from '../../models/app.userwithsec';
import { MerchantWithSec } from '../../models/app.merchantwithsec';
import { AdminWithSec } from '../../models/app.adminwithsec';
import { User } from '../../models/app.user';
import { SecurityAns } from '../../models/app.security';
import { Merchant } from '../../models/app.MERCHANT';
import { Admin } from '../../models/app.ADMIN';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';

@Component({

    selector: 'sign-up',
    templateUrl: 'app.signup.html'
})

export class SignUpComponent {

    firstName: string = "";
    lastName: string = "";
    mobileNo: number;
    address: string = "";
    emailId: string = "";
    password: string = "";
    confirmPass: string = "";
    category: string = "";
    company: string = "";
    firstSecurityQuestion:string="";
    secondSecurityQuestion:string="";
    str2:string
    str3:string

    constructor(private router:Router,private service: RegistrationServiceComponent) { 
        this.str2 = sessionStorage.getItem('admin')
    //alert(this.str2)
    if(this.str2 != null){
      this.router.navigate(['admin'])
    }

    this.str3 = sessionStorage.getItem('user')
    if(this.str3 != null){
      this.router.navigate(['home'])
    }
    }

    checkPass() {

        //console.log(this.password+"  "+this.confirmPass)
        //this.password.localeCompare(this.confirmPass)
        console.log(this.emailId)
        if (this.password == this.confirmPass)
            this.addAccount();
        else {
            this.password = "";
            this.confirmPass = "";
            alert("Password Does Not Match. Please Re-Enter them");
        }
    }


    addAccount(): any {
       
        if (this.category == "User") {
            this.service.addUser(new UserWithSec(
                new User(this.firstName, this.lastName, this.mobileNo,
                this.address, this.emailId, this.set("TheBestSecretKey",this.password)),
                new SecurityAns(this.emailId, this.firstSecurityQuestion,
                    this.secondSecurityQuestion))).subscribe(data=> alert(data.message))
        }

        if (this.category == "Merchant") {
            this.service.addMerchant(new MerchantWithSec(
                new Merchant(this.firstName, this.lastName, this.company,this.mobileNo,
                this.emailId, this.set("TheBestSecretKey",this.password)),
                new SecurityAns(this.emailId, this.firstSecurityQuestion,
                    this.secondSecurityQuestion))).subscribe(data=> alert(data.message))
                }
        if (this.category == "Admin") {
            this.service.addAdmin(new AdminWithSec(
                new Admin(this.firstName, this.lastName, this.emailId, this.set("TheBestSecretKey",this.password)),
                new SecurityAns(this.emailId, this.firstSecurityQuestion,
                    this.secondSecurityQuestion))).subscribe(data=> alert(data.message))
        }
        this.firstName = "";
        this.lastName = "";
        this.mobileNo=null;
        this.address = "";
        this.emailId = "";
        this.password = "";
        this.confirmPass = "";
        this.category = "";
        this.company = "";
        this.firstSecurityQuestion="";
        this.secondSecurityQuestion="";
        this.router.navigate(['login'])
    }
    set(keys:string, value:string):string{
        var key = CryptoJS.enc.Utf8.parse(keys);
        var iv = CryptoJS.enc.Utf8.parse(keys);
        var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(value), key,
        {
            keySize: 16,
            iv: iv,
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
    
    
    
        return encrypted.toString();
    
       }
}