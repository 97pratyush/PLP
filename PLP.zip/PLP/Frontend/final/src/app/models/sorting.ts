export class Sorting{
    category: string;
    sortingType: string
}