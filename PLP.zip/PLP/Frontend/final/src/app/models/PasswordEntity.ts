export interface PasswordEntity{
    email:string
    old_password:string
    new_password:string
    confirm_password:string
    category:string
    
}