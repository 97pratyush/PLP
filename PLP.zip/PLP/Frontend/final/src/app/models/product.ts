import { Merchant } from "./merchant";

export class Product{
    productID: number;
    productName: string;
    merchant: Merchant;
    tag: string[];
    company: string;
    photo: string;
    description: string;
    quantity: number;
    category: string;
    subcategory: string;
    soldQuantities: number;
    price: number;
    releaseDate: Date;

    getProductName(){
        return this.productName;
    }

    // constructor(productID,productName,tag,company,photo,description,quantity,category,subcategory,soldQuantities,price,releaseDate){
    //     this.productID=productID;
    //     this.productName=productName;
    //     this.tag=tag;
    //     this.company=company;
    //    this.photo=photo;
    //     this.description=description;
    //     this.quantity=quantity;
    //     this.category=category;
    //     this.subcategory=subcategory;
    //     this.soldQuantities=soldQuantities;
    //     this.price=price;
    //     this.releaseDate=releaseDate;
    // }
}
import { Merchant1 } from "./merchant";

export class Product1 {
    productName: string
    merchant: Merchant1

    getMerchant(): Merchant1 {
        return this.merchant
    }
}

export class Product2
{
    ProductId:number;
    quantity:number;
    price:number;
}
