import { InvoiceService } from './../invoice.service';
import { Component } from '@angular/core';
import { Invoice } from '../invoice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-invoice-generate',
  templateUrl: './invoice-generate.component.html',
  styleUrls: ['./invoice-generate.component.css']
})
export class InvoiceGenerateComponent {
  invoiceid: number;
  invoice: Invoice;
  constructor(private service: InvoiceService, private router: Router) {
    this.invoiceid = 1001;

    alert("Your Invoice ID is : " + this.invoiceid)
    this.change();
    this.showinvoice();
    // console.log(this.invoice);
  }
  er: Error

  showinvoice() {
    console.log(this.invoiceid)
    //Paramterize showInvoice when it takes order id after integration
    this.service.showInvoice().subscribe(data => {
      this.invoice = data[0];
      console.log(this.invoice);
    },
      err => this.er = err)
  }

  ch = false;
  change() {
    this.ch = true
  }

}
