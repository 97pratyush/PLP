package com.invoice.service;

import java.util.List;

import com.invoice.bean.Invoice;

public interface InvoiceService {

	List<Invoice> getInvoice();
	
}
