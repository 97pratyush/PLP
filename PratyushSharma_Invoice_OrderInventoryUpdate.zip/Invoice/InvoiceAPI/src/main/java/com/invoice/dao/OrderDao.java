package com.invoice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.invoice.bean.Orders;

public interface OrderDao extends JpaRepository<Orders, Integer> {

}
