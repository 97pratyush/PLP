package com.invoice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.invoice.bean.Invoice;
import com.invoice.bean.Orders;
import com.invoice.bean.Transaction;
import com.invoice.dao.OrderDao;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

	Orders order;
	Transaction trans;
	Invoice invoice;

	@Override
	public List<Invoice> getInvoice() {

		List<Invoice> data = new ArrayList<>();

		// Used just for testing

		int cId = 1002;
		int pId = 1003;
		int mId = 1004;
		int quantity = 50;
		double amount = 55555;

		/*
		 * int cId = order.getCustomerId(); int pId = order.getProductId(); int mId =
		 * order.getMerchantId(); int quantity = order.getQuantity(); double amount =
		 * trans.getAmount();
		 */

		invoice = new Invoice(1001, 2001, cId, pId, mId, quantity, amount);

		data.add(invoice);

		System.out.println(data);

		return data;
	}

}
