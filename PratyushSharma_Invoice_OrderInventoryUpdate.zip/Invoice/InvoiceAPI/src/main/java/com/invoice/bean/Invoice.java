package com.invoice.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Invoice {

	@Id
	@SequenceGenerator(name = "invoice_id", sequenceName = "invoice_id", initialValue = 11000, allocationSize = 1)
	@GeneratedValue(generator = "invoice_id")
	private int invoiceId;
	private int orderId;
	private int customerId;
	private int productId;
	private int merchantId;
	private int quantity;
	private double totalAmount;

	public int getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public Invoice() {
		super();
	}
	
	public Invoice(int invoiceId, int orderId, int customerId, int productId, int merchantId, int quantity,
			double totalAmount) {
		super();
		this.invoiceId = invoiceId;
		this.orderId = orderId;
		this.customerId = customerId;
		this.productId = productId;
		this.merchantId = merchantId;
		this.quantity = quantity;
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "Invoice [invoiceId=" + invoiceId + ", orderId=" + orderId + ", customerId=" + customerId
				+ ", productId=" + productId + ", merchantId=" + merchantId + ", quantity=" + quantity
				+ ", totalAmount=" + totalAmount + "]";
	}
	
	

}
