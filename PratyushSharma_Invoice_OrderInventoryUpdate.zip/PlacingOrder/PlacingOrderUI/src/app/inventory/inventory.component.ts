import { InventoryService } from './../service/inventory.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  available: boolean;
  message: string;

  constructor(private inventoryService: InventoryService) { }

  ngOnInit() {
  }

  checkAvailabilty(prodId: number) {
    this.inventoryService.checkAvailabilty(prodId).subscribe(data => {
    this.available = data;
      if (this.available) {
        this.message = 'Yes, it is available';
      }
      else {
        this.message = 'Sorry, it is Out of Stock'
      }
    }, (err) => alert('Error Displaying data.'));
  }

  updateInventory(prodId: number) {
    this.inventoryService.updateInventory(prodId).subscribe(data => {
      if(!data){
        alert("Removed 1 product from inventory.")
      }
      else {
        alert("Product not found.")
      }
    })
  }

}
