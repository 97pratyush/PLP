package com.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.bean.Inventory;
import com.order.dao.InventoryDao;
import com.order.exception.OrderException;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	InventoryDao inventoryDao;

	@Override
	public boolean checkAvailability(int prodId) throws OrderException {
		if (!inventoryDao.existsById((Integer) prodId)) {
			throw new OrderException("Product doesn't exist.");
		} else {
			if (inventoryDao.checkInventory(prodId) == 0)
				return false;
			else
				return true;
		}
	}

	@Override
	public boolean updateInventory(int prodId) throws OrderException {
		if (inventoryDao.existsById((Integer) prodId)) {
			Inventory inventory = inventoryDao.findById((Integer) prodId).get();
			int quantity = inventory.getQuantity();
			inventory.setQuantity(quantity - 1);
			inventoryDao.save(inventory);
			return true;
		} else {
			return false;
		}
	}

}
