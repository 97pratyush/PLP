package com.order.service;

import com.order.exception.OrderException;

public interface OrderService {

	public boolean checkAvailability(int prodId) throws OrderException;

	public boolean updateInventory(int prodId) throws OrderException;

}
