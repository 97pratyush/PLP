package com.order.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.order.bean.Inventory;

public interface InventoryDao extends JpaRepository<Inventory, Integer>{
	
	@Query("select quantity from Inventory where productId=:prodId")
	public int checkInventory(@Param("prodId") int prodId);

}
