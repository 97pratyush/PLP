package com.order.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Inventory {

	private int mid;
	@Id
	private int productId;
	private int quantity;
	private Date last_updated;
	
	public Inventory() {
		super();
	}

	public Inventory(int mid, int productId, int quantity, Date last_updated) {
		super();
		this.mid = mid;
		this.productId = productId;
		this.quantity = quantity;
		this.last_updated = last_updated;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getLast_updated() {
		return last_updated;
	}

	public void setLast_updated(Date last_updated) {
		this.last_updated = last_updated;
	}

	@Override
	public String toString() {
		return "Inventory [mid=" + mid + ", productId=" + productId + ", quantity=" + quantity + ", last_updated="
				+ last_updated + "]";
	}
	
	
}
