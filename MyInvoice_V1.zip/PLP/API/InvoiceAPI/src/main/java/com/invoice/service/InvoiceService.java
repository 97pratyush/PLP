package com.invoice.service;



import com.invoice.bean.Transaction;
import com.invoice.bean.User1;
import com.invoice.model.InvoiceProductModel;

public interface InvoiceService {

	public InvoiceProductModel showInvoice(int orderid);

	public User1 getUser(int userid);

	public void saveTransaction(Transaction transactionObject);

	public Transaction showTransaction(int orderid);
}
