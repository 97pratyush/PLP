package com.invoice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.invoice.bean.Invoice;

public interface InvoiceDAO extends JpaRepository<Invoice, Integer>{

}
