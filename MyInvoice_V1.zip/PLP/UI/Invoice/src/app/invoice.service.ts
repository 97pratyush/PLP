import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { InvoiceProduct } from "./InvoiceProduct";

@Injectable({
    providedIn: 'root'
})

export class InvoiceService {
    constructor(private http: HttpClient) {

    }

    showInvoice(orderid: string) {
        let option = {
            "headers":
                new HttpHeaders({ "Content-Type": "application/json" })
        };
        return this.http.get<InvoiceProduct>('http://localhost:9090/invoice/get/' + orderid, option);
    }
}
