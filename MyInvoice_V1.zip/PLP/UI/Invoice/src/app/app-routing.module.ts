import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InvoiceGenerateComponent } from './invoice-generate/invoice-generate.component';


const routes: Routes = [
  { path: 'invoice', component: InvoiceGenerateComponent },
  { path: '', redirectTo: 'invoice', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
