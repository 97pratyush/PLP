import { Invoice } from "./Invoice";
import { Product } from "./Product";

export class InvoiceProduct {

    invoiceObject: Invoice;
    productsList: Product[];
}
