import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  available: boolean;

  constructor(private http: HttpClient) { }

  checkAvailabilty(prodId: number):Observable<boolean> {
    return this.http.get<boolean>("http://localhost:6500/check/"+prodId);
  }

  updateInventory(prodId: number):Observable<boolean> {
    return this.http.get<boolean>("http://localhost:6500/update/"+prodId);
  }

}
