package com.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.order.exception.OrderException;
import com.order.service.OrderServiceImpl;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class OrderController {

	@Autowired
	OrderServiceImpl orderService;

	@GetMapping("/check/{prodId}")
	public boolean checkAvailability(@PathVariable int prodId) throws OrderException {
		return orderService.checkAvailability(prodId);
	}
	
	@GetMapping("/update/{prodId}")
	public boolean updateAvailability(@PathVariable int prodId) throws OrderException {
		return orderService.updateInventory(prodId);
	}
}
