import { InvoiceService } from './../invoice.service';
import { Component } from '@angular/core';
import { Invoice } from '../invoice';

@Component({
  selector: 'app-invoice-generate',
  templateUrl: './invoice-generate.component.html',
  styleUrls: ['./invoice-generate.component.css']
})
export class InvoiceGenerateComponent {
  orderId: number;
  invoice: Invoice;
  constructor(private service: InvoiceService) {

    // alert("Your Invoice ID is : " + this.orderId)
    // this.change();
    // this.showinvoice();
    // console.log(this.invoice);
  }
  er: Error

  showinvoice(orderId: number) {
    //Paramterize showInvoice when it takes order id after integration
    this.service.showInvoice(orderId).subscribe(data => {
      this.invoice = data[0];
    },
      err => this.er = err);;
  }

  ch = false;
  change() {
    this.ch = true
  }

}

