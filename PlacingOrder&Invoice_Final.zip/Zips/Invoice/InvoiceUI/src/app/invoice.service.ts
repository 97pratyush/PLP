import { Observable } from 'rxjs';
import { Invoice } from './invoice';
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})

export class InvoiceService {

  invoice: Invoice;

  constructor(private http: HttpClient) { }

  //Paramterize showInvoice when it takes order id after integration
  showInvoice(orderId : number):Observable<Invoice> {
    return this.http.get<Invoice>('http://localhost:9090/invoice/'+orderId);
  }
}
