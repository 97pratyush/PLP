export interface Invoice {
  customerId: number
  invoiceId: number
  merchantId: number
  orderId: number
  productId: number
  quantity: number
  totalAmount: number
}
