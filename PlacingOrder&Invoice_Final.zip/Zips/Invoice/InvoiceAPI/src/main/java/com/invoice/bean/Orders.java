package com.invoice.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Orders {
	@Id
	@SequenceGenerator(name = "order_id", sequenceName = "order_id", initialValue = 60000, allocationSize = 1)
	@GeneratedValue(generator = "order_id")
	private int orderId;
	private int customerId;
	private int productId;
	private int merchantId;
	private int quantity;
	private String status;

	public Orders() {
		super();
	}

	public Orders(int orderId, int customerId, int productId, int merchantId, int quantity,
			String status) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.productId = productId;
		this.merchantId = merchantId;
		this.quantity = quantity;
		this.status = status;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", customerId=" + customerId + ", productId=" + productId
				+ ", merchantId=" + merchantId + ", quantity=" + quantity + ", status="
				+ status + "]";
	}

}
