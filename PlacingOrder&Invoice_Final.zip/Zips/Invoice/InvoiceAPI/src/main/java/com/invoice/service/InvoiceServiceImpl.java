package com.invoice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.invoice.bean.Invoice;
import com.invoice.bean.Orders;
import com.invoice.bean.Transaction;
import com.invoice.dao.InvoiceDao;
import com.invoice.dao.OrderDao;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

	@Autowired
	OrderDao orderDao;
	
	@Autowired
	InvoiceDao invoiceDao;

	Orders order;
	Invoice invoice;

	@Override
	public List<Invoice> getInvoice(int orderId) {

		List<Invoice> data = new ArrayList<>();
		
		order = orderDao.findById((Integer) orderId).get();

		int cId = order.getCustomerId();
		int pId = order.getProductId();
		int mId = order.getMerchantId();
		int quantity = order.getQuantity();

		invoice = new Invoice(orderId, orderId, cId, pId, mId, quantity, 9000);

		data.add(invoice);
		invoiceDao.save(invoice);
		return data;
	}

}
