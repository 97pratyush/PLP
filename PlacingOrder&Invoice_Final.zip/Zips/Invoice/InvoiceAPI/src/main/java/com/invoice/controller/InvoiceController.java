package com.invoice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.invoice.bean.Invoice;
import com.invoice.service.InvoiceService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class InvoiceController {

	@Autowired
	private InvoiceService invoiceService;
	
	@GetMapping("/invoice/{orderId}")
	public List<Invoice> getInvoice(@PathVariable int orderId) {
		return invoiceService.getInvoice(orderId);
	}

}
